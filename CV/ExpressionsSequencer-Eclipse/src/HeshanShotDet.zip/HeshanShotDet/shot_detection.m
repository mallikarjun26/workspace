% This function takes the avi filename as input and detect hard cuts.

function []=shot_detection(aviFileName)
% extact frames from video and output them as bmp files
movieObj = aviread(aviFileName);
noOfFrameImages = size(movieObj,2);

for count=1:1:noOfFrameImages
    imageFileNamePrefix = 'bmp\framedump_';
    
    fileName = strcat(imageFileNamePrefix,num2str(count),'.bmp');
    imwrite(movieObj(count).cdata,fileName,'bmp');    
end

% calculate fetures values based on histogram dissimilarity
featureHist = getHistogramFeature(imageFileNamePrefix, noOfFrameImages);

% calculate fetures values based on ECR
featureECR = getECRFeature(imageFileNamePrefix, noOfFrameImages);

% detect hard cuts use adaptive threshold
cutHist = cutDetect(featureHist);
cutECR = cutDetect(featureECR);

% plot the result
figure; plot(featureHist(:,1),featureHist(:,2)); 
xlabel('Frame Number'); ylabel('Histogram Feature Value'); 
hold; plot(cutHist(:,1),cutHist(:,2),'rx'); legend('f(n)', 'cut');

figure; plot(featureECR(:,1),featureECR(:,2)); 
xlabel('Frame Number'); ylabel('ECR Feature Value'); 
hold; plot(cutECR(:,1),cutECR(:,2),'rx'); legend('f(n)', 'cut');

return;
