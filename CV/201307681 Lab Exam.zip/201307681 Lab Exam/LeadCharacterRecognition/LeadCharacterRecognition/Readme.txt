Usage:





Development:

Step 1: 
Face detection- Detecting all possible faces from the video using haar features. I've used only haarcascade_frontalface_default, which came along with opencv. Clustering will take a hit if I choose to detect tilted faces as well. So ignored the faces other than the frontal part of it. 




