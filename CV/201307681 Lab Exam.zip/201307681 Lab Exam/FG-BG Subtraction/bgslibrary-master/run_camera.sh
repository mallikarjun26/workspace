#!/bin/bash
./build/bgs --use_cam --camera=0

