#!/bin/bash
# ./build/bgs -uf -fn=dataset/video.avi
#./build/bgs -uf -fn=/home/mallikarjun/Documents/CV/Lab\ Exam/Video/test4.mp4
./build/bgs -uf -fn=/home/mallikarjun/Desktop/test.webm

