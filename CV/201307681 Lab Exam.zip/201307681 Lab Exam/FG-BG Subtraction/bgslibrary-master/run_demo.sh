#!/bin/bash
./build/bgs_demo dataset/video.avi

