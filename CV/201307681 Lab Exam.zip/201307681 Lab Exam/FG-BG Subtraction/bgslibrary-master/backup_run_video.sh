#!/bin/bash
./build/bgs -uf -fn=dataset/video.avi

